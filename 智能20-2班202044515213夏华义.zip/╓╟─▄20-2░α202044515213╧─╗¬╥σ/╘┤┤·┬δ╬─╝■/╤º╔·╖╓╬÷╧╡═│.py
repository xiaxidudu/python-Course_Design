import tkinter as tk,json,threading
from class_write import verification
import  pandas as pd,os,xlrd;from tkinter import filedialog
import matplotlib.pyplot as plt
from PIL import Image
import tkinter.messagebox
plt.rcParams['font.sans-serif']=['Youyuan']
data_file_name=[]#存储用户选择的文件夹下的文件row=0, column=1
all_data={}#储存#alldate={a:{xm:'',km:''},b:{xm:'',km:""}}
all_course=[]
all_class=[]







####################预处理开始
example_operating=verification()#生成自己写的类
try:
    key1 = 131420
    name_pasd_Undecrypted=json.load(open("账号-密码.json",'r'))
    name_mail=json.load(open("账号-邮箱.json",'r'))
    name_pasd={}
    for x in name_pasd_Undecrypted:
        ppsd2 = ''
        for y in range(len(name_pasd_Undecrypted[x])):
            ppsd2 = ppsd2 + chr(ord(name_pasd_Undecrypted[x][y])^key1)
            name_pasd[x]=ppsd2
except:
    tkinter.messagebox.showerror('警告', '程序初始化错误')
####################预处理结束
###########################数据数据处理有关函数
def file_name_get():
    global data_file_name,deal_date
    try:
        wjcd=filedialog.askdirectory()
        for files in os.listdir(wjcd):
            all_course.append(files[files.find("成")-2:files.find("成")])
            all_class.append(files[files.find("的") - 2:files.find("的")])
            excel_read = xlrd.open_workbook(wjcd + '/' + files)
            sheet1_ = excel_read.sheet_by_index(0)
            for x in range(1, sheet1_.nrows):
                sheet_value = sheet1_.row_values(x)
                try:
                    all_data[sheet_value[0]][files[-9:-7]] = sheet_value[2]
                    all_data[sheet_value[0]]['总分'] += sheet_value[2]
                except:
                    all_data[sheet_value[0]] = dict([('学号', sheet_value[0]), ('姓名', sheet_value[1]),('班级',files[:files.find("的")]), (files[-9:-7], sheet_value[2])])
                    all_data[sheet_value[0]]['总分'] = sheet_value[2]
        deal_date = pd.DataFrame(all_data).T
        all_rank()
    except:
        tkinter.messagebox.showerror('警告', '未选择储存文件位置或未选择有效学生成绩文件夹')
def return_value_window( x, y, widow):  # 返回居中数用于对窗口的居中显示
    screenwidth, screenheight = widow.winfo_screenwidth(), widow.winfo_screenheight()
    return '%dx%d+%d+%d' % (x, y, (screenwidth - x) / 2, (screenheight - y) / 2)
def student_compare(studentone,studenttwo):

    if studentone in all_data and studenttwo in all_data:
        plt.clf()
        class_list = list(set(all_course))
        Grade_list1 = [all_data[studentone][class_list[x]] for x in range(len(class_list))]
        Grade_list2 = [all_data[studenttwo][class_list[x]] for x in range(len(class_list))]
        total_width, n = 0.8, 2
        width = total_width / n
        x1=[x for x in range(len(set(all_course)))]
        x2=[x+width for x in x1]
        plt.bar(x1, Grade_list1, width=width, label=all_data[studentone]['姓名']+studentone, tick_label=class_list)
        plt.bar(x2, Grade_list2, width=width, label=all_data[studenttwo]['姓名']+studenttwo)
        for a, b in zip(x1, Grade_list1):  # 柱子上的数字显示
            plt.text(a, b, '%.2f' % b, ha='center', va='bottom', fontsize=7)
        for a, b in zip(x2, Grade_list2):
            plt.text(a, b, '%.2f' % b, ha='center', va='bottom', fontsize=7)
        plt.legend()
        plt.savefig('pc.png')
        pic=Image.open('pc.png')
        pic.show()
    else:
        tkinter.messagebox.showerror('警告',"学 生 信 息 有 误")
def all_rank():
    global frame_data
    frame_data = deal_date.sort_values(by="总分", ascending=False)
    frame_data.index = range(len(frame_data))
    rank = []
    Contrast_value = frame_data.loc[0]['总分']
    Contrast_rank = 1
    for x in range(0, len(frame_data)):
        if frame_data.loc[int(x)]['总分'] == Contrast_value:
            rank.append(Contrast_rank)
            all_data[frame_data.loc[int(x)]['学号']]['总排名']=Contrast_rank
        else:
            rank.append(x + 1)
            Contrast_value = frame_data.loc[int(x)]['总分']
            Contrast_rank = 1 + x
            all_data[frame_data.loc[int(x)]['学号']]['总排名'] = 1+x
    frame_data['总排名'] = rank
    frame_data.to_excel(save_wjcd+'/'+'年级总排名.xls')
    for y in set(all_course):
        frame_data1 = frame_data.sort_values(by=y, ascending=False)
        frame_data1.index = range(len(frame_data1))
        rank = []
        Contrast_value = frame_data1.loc[0][y]
        Contrast_rank = 1
        for x in range(0, len(frame_data)):
            if frame_data1.loc[x][y] == Contrast_value:
                rank.append(Contrast_rank)
            else:
                rank.append(x + 1)
                Contrast_value = frame_data1.loc[x][y]
                Contrast_rank = 1 + x
        frame_data1[y+'排名'] = rank
        frame_data1.to_excel(save_wjcd+'/'+'年级的'+y+'排名.xls')
    for  y in set(all_class):
        short_dict_rank={}
        for x in all_data:
            if all_data[x]['班级']==y:
                short_dict_rank[x]=all_data[x]
        deal_date2 = pd.DataFrame(short_dict_rank).T
        deal_date1=deal_date2.sort_values(by='总分', ascending=False)
        deal_date1.index = range(len(deal_date1))

        rank = []
        Contrast_value = deal_date1.loc[0]['总分']
        Contrast_rank = 1
        for x in range(0, len(deal_date1)):
            if deal_date1.loc[int(x)]['总分'] == Contrast_value:
                rank.append(Contrast_rank)
            else:
                rank.append(x + 1)
                Contrast_value = deal_date1.loc[int(x)]['总分']
                Contrast_rank = 1 + x
        deal_date1['班级排名'] = rank
        deal_date1.to_excel(save_wjcd+'/'+y+'排名.xls')
def save_file_get():
    global save_wjcd
    try:
        save_wjcd = filedialog.askdirectory()
    except:
        tkinter.messagebox.showerror('警告',"未选择有效文件夹" )
def contrast():
    window_start = tk.Tk()
    window_start.title("学生选择")
    window_start.geometry(return_value_window(360,130,window_start))
    window_start.resizable(0,0)
    tk.Label(window_start, text="第一位学生").grid(row=0)
    tk.Label(window_start, text="第二位学生").grid(row=1)
    one = tk.Entry(window_start)
    two = tk.Entry(window_start)
    one.grid(row=0, column=1, padx=10, pady=5)
    two.grid(row=1, column=1, padx=10, pady=5)
    tk.Button(window_start, text="确定", width=10, command=lambda :student_compare(one.get(),two.get())).grid(row=3, column=2, sticky="e", padx=10, pady=5)
    window_start.mainloop()
def Statistics():
    window_data=tk.Tk()
    window_data.title("开始")
    window_data.resizable(0,0)
    window_data.geometry(return_value_window(200,90,window_data))
    tk.Button(window_data, text='选 择 存 储 位 置', command=save_file_get).grid()
    tk.Button(window_data,text="读 取 指 定 文 件",command=file_name_get).grid()
    tk.Button(window_data,text="比 对 学 生 成 绩",command=contrast).grid()
    window_data.mainloop()
#####################################登录函数
def sign_up_get(transfer):#获取注册输入界面，将输入打包为列表
    global window_sign
    window_sign=tk.Tk()
    window_sign.geometry(return_value_window(400,120,window_sign))
    window_sign.resizable(0,0)
    tk.Label(window_sign, text='注册用户：').grid(row=0, column=0)
    tk.Label(window_sign, text="设定密码：").grid(row=1, column=0)
    tk.Label(window_sign, text="注意：用户为8位数字,密码长度为8-16位").grid(row=2, column=0)
    name = tk.Entry(window_sign)
    password = tk.Entry(window_sign)
    name.grid(row=0, column=1, padx=10, pady=5)
    password.grid(row=1, column=1, padx=10, pady=5)
    tk.Button(window_sign, text=" 注    册 ", command=lambda :judgment_procedure(name.get(),"accounts_exist_verify-for-sign",[transfer,name.get(),password.get()])).grid(row=2, column=1)
    window_sign.mainloop()
def change_get(transfer):
    global window_change
    window_change= tk.Tk()
    window_change.title("重置")
    window_change.resizable(0, 0)
    window_change.geometry(return_value_window(360,100,window_change))
    tk.Label(window_change, text="重置密码：").grid(row=0, column=0)
    tk.Label(window_change, text="注意：      密 码 长 度 为 8 - 16 位").grid(row=1, column=0)
    password = tk.Entry(window_change)
    password.grid(row=0, column=1, padx=10, pady=5)
    tk.Button(window_change, text=" 重  置 ", command=lambda: judgment_procedure(password.get(), "accounts_lenth_verify-for-change",[transfer, password.get()])).grid(row=1,column=1)
    window_change.mainloop()
def judgment_procedure(enter,adjust,transfer):#判别程序
    global name_mail,name_pasd,example_operating
    if adjust=='accounts_exist_verify-for-change':
        if enter in name_mail:
            EMAIL_SENT(name_mail[enter],'密码修改')
        else:
            tkinter.messagebox.showerror('警告',"不  存  在  该  用 户")
    if adjust=="accounts_lenth_verify-for-change":#密码修改
        if 7<len(enter)<17:
            if tk.messagebox.askokcancel('提示', '确定修改吗'):
                window_change.destroy()
                key = 131420
                ppsd = ''
                for x in range(len(transfer[1])):
                    ppsd = ppsd + chr(key ^ ord(transfer[1][x]))
                name_pasd[transfer[0][0]] = ppsd
                json.dump(name_pasd, open("账号-密码.json", 'w'))
                name_pasd[transfer[0][0]]=transfer[1]
                tk.messagebox.askokcancel('提示', '修改成功')
        else:
            tk.messagebox.showerror('错误', '密码设置错误')

    if adjust=="accounts_exist_verify-for-sign":
        if enter in name_mail:
            tk.messagebox.showerror('错误', '用户已经存在!')
        else:
            if len(transfer[1])!=8:
                tk.messagebox.showerror('错误', '账号设置错误')
            if 7<len(transfer[2])<17:
                sign_in(transfer)
            else:
                tk.messagebox.showerror('错误', "密  码  设  置  错  误")
    if adjust=='mail_compared_verify_sign':#邮箱注册验证
        if enter==example_operating.look_return_ver_value() :#注册获取
            window_interface.destroy()
            example_operating.default()
            example_operating.timer_killer(1)
            sign_up_get(transfer)
        else:
            tk.messagebox.showerror('错误',"验证失败")
    if adjust=='mail_compared_change':
        if enter==example_operating.look_return_ver_value():#修改器获取
            window_interface.destroy()
            example_operating.default()
            example_operating.timer_killer(1)
            change_get(transfer)
        else:
            tk.messagebox.showerror('错误',"验证失败")
def Email_verification(adjust):#电子邮件验证界面
    global example_operating,window_interface,name_mail
    window_interface = tk.Tk()
    window_interface.title("验证")
    window_interface.resizable(0, 0)
    window_interface.geometry(return_value_window(260,100,window_interface))
    tk.Label(window_interface, text="验证码").grid(row=1)
    name_or_mail = tk.Entry(window_interface)
    password = tk.Entry(window_interface)
    name_or_mail.grid(row=0, column=1, padx=10, pady=5)
    password.grid(row=1, column=1, padx=10, pady=5)
    tk.Label(window_interface, text="注意: 验证码有效时间为60s").grid(row=2, column=1)
    if adjust==0:#启动密码修改
        tk.Label(window_interface, text='账号').grid(row=0)
        tk.Button(window_interface, text="获取",command=lambda :judgment_procedure(name_or_mail.get(),"accounts_exist_verify-for-change",[0])).grid(row=1, column=3)
        tk.Button(window_interface, text='进入修改',command=lambda : judgment_procedure(password.get(),'mail_compared_change',[name_or_mail.get(),password.get()]) ).grid(row=2, column=0)
    else:#启动账号注册
        tk.Label(window_interface, text='邮箱').grid(row=0)
        tk.Button(window_interface, text="获取",command=lambda :EMAIL_SENT(name_or_mail.get(),'账号注册') ).grid(row=1, column=3)
        tk.Button(window_interface, text='进入注册',command=lambda :judgment_procedure(password.get(),'mail_compared_verify_sign',[name_or_mail.get()])).grid(row=2, column=0)
    window_interface.mainloop()
def EMAIL_SENT(email,tile):
    global example_operating
    try:
        example_operating.Mailing(email,tile)
        example_operating.timer_start()
    except:
        tkinter.messagebox.showerror('警告',"邮箱不合法")
#################初始窗口的生成
def start():
    global  window_start
    try:
        window_start = tk.Tk()
        #window_start[ "background"]='#D3D3D3'
        window_start.title("登录界面")
        window_start.geometry(return_value_window(360,130,window_start))
        window_start.resizable(0,0)
        tk.Label(window_start, text="账户：").grid(row=0)
        tk.Label(window_start, text="密码：").grid(row=1)
        user = tk.Entry(window_start)
        password = tk.Entry(window_start,show='*')
        user.grid(row=0, column=1, padx=10, pady=5)
        password.grid(row=1, column=1, padx=10, pady=5)
        tk.Button(window_start, text="登录", width=10,command=lambda : get_in(user.get(),password.get())).grid(row=3, column=0, sticky="w", padx=10, pady=5)
        tk.Button(window_start, text="注册账号", width=10,command=lambda :Email_verification(1)).grid(row=0, column=2, sticky="E", padx=10, pady=5)
        tk.Button(window_start, text="忘记密码", width=10,command=lambda :Email_verification(0)).grid(row=1, column=2, sticky="E", padx=10, pady=5)
        tk.Button(window_start, text="退出", width=10,command=window_start.quit).grid(row=3, column=2, sticky="e", padx=10, pady=5)
        window_start.mainloop()
    except:
        pass
###############
def get_in(user,psd):
    if user in name_mail:
        if psd == name_pasd[user]:
            window_start.destroy()
            Statistics()
        else:
            tk.messagebox.showerror('错误', "密码错误")
    else:
        tk.messagebox.showerror('错误', "不存在改用户")
def sign_in(transfer):#写入
    window_sign.destroy()
    key=131420
    ppsd=''
    for x in range(len(transfer[2])):
        ppsd=ppsd+chr(key ^ ord(transfer[2][x]))
    name_pasd[transfer[1]]=ppsd
    name_mail[transfer[1]]=transfer[0][0]
    json.dump(name_pasd,open("账号-密码.json",'w'))
    json.dump(name_mail,open("账号-邮箱.json", 'w'))
    name_pasd[transfer[1]] = transfer[2]
    tk.messagebox.askokcancel('提示', "注册成功")
if __name__ == '__main__':
    start()


