from smtplib import SMTP_SSL
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header
import random,tkinter as tk,time
class  verification():
    def __init__(self):
        self.Recipient=''#收件人的邮箱地址
        self.Verification_code=''#验证码
        self.__LocalVerification_code='000000'#本地验证码默认为六位数
        #输入验证码将会进行处理只保留四个，90秒后或者通过后默认为000000
        self.__sender='3337562545@qq.com'
        self.__senderpsd='riseyhnhhfypdbeg'
    def timer(self,window_timer,text):#计时器
        if text == '0':
            self.default()
            window_timer.destroy()
        try:
            tk.Label(window_timer,text="验证码有效期还剩："+text+"s",font=20).grid(row=1,column=1)
            window_timer.update()
            time.sleep(1)
        except:
            pass

    def __randomnumber(self):#生成一个长度为四个数字的随机字符串
        numbers = ''
        for x in range(4):
            number = random.randint(0, 9)
            numbers = numbers + str(number)
        return numbers
    def Mailing(self,e_ail,title_in):

        self.Recipient = e_ail
        host_server = 'smtp.qq.com'  # qq邮箱smtp服务器
        message=MIMEMultipart()#初始化邮箱主体
        message["Subject"] = Header(title_in,'utf-8')#设置发送标题为
        message["From"]=self.__sender
        message['To']=self.Recipient
        self.__LocalVerification_code=self.__randomnumber()#生成本地验证码
        message.attach(MIMEText(self.__LocalVerification_code))
        smtp = SMTP_SSL(host_server)  # ssl登录
        smtp.login(self.__sender, self.__senderpsd)#进行登录
        smtp.sendmail(self.__sender,self.Recipient,message.as_string())
        smtp.quit()
    def timer_start(self):
        global window_timer
        window_timer=tk.Tk()
        window_timer.resizable(0,0)
        for x in range(59,-1,-1):
            try:
                self.timer(window_timer,str(x))
            except:
                break

    def default(self):#重置
        self.__LocalVerification_code='000000'
    def look_return_ver_value(self):#返回本地验证码
        return self.__LocalVerification_code
    def timer_killer(self,commander):
        if commander==1:
            self.default()
            window_timer.destroy()

